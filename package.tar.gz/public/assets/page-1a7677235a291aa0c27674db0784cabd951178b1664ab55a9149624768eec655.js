(() => {
  // app/javascript/page.js
  window.onpageshow = function() {
    var clipboard = new ClipboardJS(".btn");
    clipboard.on("success", function(e) {
      console.info("Action:", e.action);
      console.info("Text:", e.text);
      console.info("Trigger:", e.trigger);
      e.clearSelection();
    });
    $("body").popover({
      selector: ".focus-popover",
      trigger: "hover focus"
    });
    if ($("#dashboard_view").size() != 0) {
      $("#dashboard_view").bootstrapTable();
    }
    if ($("#work_table").size() != 0) {
      $.get("/data/work?" + document.URL.split("?")[1]);
    }
  };
})();
//# sourceMappingURL=/assets/page.js-cc806169c0b3ca52236bb272311d24b2832b1935dd3ef69572e3eb05dafd62a5.map
//!
;
